library(reshape)
library(ggplot2)
library(corrplot)
library(caret)

source('ml.R')

# Util stuff
load.filter <- function(path) {
  setAs("character", "POSIXct",
        function(from){as.POSIXct(from, origin = "1970-01-01")})

  a <- read.csv(path, check.names = T,
                colClasses = c(
                  "integer",      #pull_req_id
                  "factor",       #project_name
                  "factor",       #lang
                  "integer",      #github_id
                  "integer",      #created_at
                  "integer",      #merged_at
                  "integer",      #closed_at
                  "integer",      #lifetime_minutes
                  "integer",      #mergetime_minutes
                  "factor",       #merged_using
                  "factor",       #conflict
                  "factor",       #forward_links
                  "factor",       #intra_branch
                  "integer",      #description_length
                  "integer",      #num_commits
                  "integer",      #num_commits_open
                  "integer",      #num_pr_comments
                  "integer",      #num_issue_comments
                  "integer",      #num_commit_comments
                  "integer",      #num_comments
                  "integer",      #num_commit_comments_open
                  "integer",      #num_participants
                  "integer",      #files_added_open
                  "integer",      #files_deleted_open
                  "integer",      #files_modified_open
                  "integer",      #files_changed_open
                  "integer",      #src_files_open
                  "integer",      #doc_files_open
                  "integer",      #other_files_open
                  "integer",      #files_added
                  "integer",      #files_deleted
                  "integer",      #files_modified
                  "integer",      #files_changed
                  "integer",      #src_files
                  "integer",      #doc_files
                  "integer",      #other_files
                  "integer",      #src_churn_open
                  "integer",      #test_churn_open
                  "integer",      #src_churn
                  "integer",      #test_churn
                  "numeric",      #new_entropy
                  "numeric",      #entropy_diff
                  "integer",      #commits_on_files_touched
                  "integer",      #commits_to_hottest_file
                  "numeric",      #hotness
                  "integer",      #at_mentions_description
                  "integer",      #at_mentions_comments
                  "numeric",      #perc_external_contribs
                  "integer",      #sloc
                  "numeric",      #test_lines_per_kloc
                  "numeric",      #test_cases_per_kloc
                  "numeric",      #asserts_per_kloc
                  "integer",      #stars
                  "integer",      #team_size
                  "integer",      #workload
                  "factor",       #ci
                  "factor",       #requester
                  "factor",       #closer
                  "factor",       #merger
                  "integer",      #prev_pullreqs
                  "numeric",      #requester_succ_rate
                  "integer",      #followers
                  "factor",       #main_team_member
                  "factor",       #social_connection
                  "integer",      #prior_interaction_issue_events
                  "integer",      #prior_interaction_issue_comments
                  "integer",      #prior_interaction_pr_events
                  "integer",      #prior_interaction_pr_comments
                  "integer",      #prior_interaction_commits
                  "integer",      #prior_interaction_commit_comments
                  "integer"      #first_response
                )
  )

  a$prior_interaction_comments <- a$prior_interaction_issue_comments + a$prior_interaction_pr_comments + a$prior_interaction_commit_comments
  a$prior_interaction_events <- a$prior_interaction_issue_events + a$prior_interaction_pr_events + a$prior_interaction_commits

  a$has_ci <- a$ci != 'unknown'
  a$has_ci <- as.factor(a$has_ci)

  a$merged <- !is.na(a$merged_at)
  a$merged <- as.factor(a$merged)
  #   # Take care of cases where csv file production was interupted, so the last
  #   # line has wrong fields
  a <- subset(a, !is.na(first_response))
  #data.table(a)
  a
}

# Actual analysis
data <- load.filter('salt.csv')

# See what data types we have in our dataset
str(data)

# Remove factors and columns to calculate correlations
numeric.fields <- c('pull_req_id',
                    'description_length','num_commits_open','num_pr_comments',
                    'num_issue_comments','num_comments','num_commit_comments_open',
                    'num_participants','files_added_open','files_deleted_open',
                    'files_modified_open','files_changed_open','src_files_open',
                    'doc_files_open','other_files_open','src_churn_open',
                    'test_churn_open','new_entropy',
                    'entropy_diff','commits_on_files_touched',
                    'commits_to_hottest_file','hotness',
                    'at_mentions_description','at_mentions_comments',
                    'perc_external_contribs','sloc','test_lines_per_kloc',
                    'test_cases_per_kloc','asserts_per_kloc','stars',
                    'team_size','workload','prev_pullreqs','requester_succ_rate',
                    'followers','prior_interaction_comments',
                    'prior_interaction_events')

numeric <- data[, numeric.fields]

# Plot histograms for interesting variables
c <- melt(numeric, id.vars = 'pull_req_id')
ggplot(c, aes(x = value)) +
  facet_wrap(~variable, scales = "free") +
  scale_x_log10()+
  geom_histogram() +
  theme_bw(base_size = 10)

#Cross correlation analysis
cor.table <- cor(numeric, method = "spearman")
corrplot(cor.table, method="circle",order = "hclust", addrect = 2)

correlated <- findCorrelation(cor.table, cutoff = 0.75, exact = T, names = T)
print(correlated)

# ML Task : Predict whether a pull request will be merged or not
model <- merged ~ intra_branch +
  description_length + num_commits_open + num_commit_comments_open +
  files_added_open + files_deleted_open +
  files_changed_open + doc_files_open + other_files_open +
  src_churn_open + test_churn_open + new_entropy + hotness +
  at_mentions_description + perc_external_contribs +
  test_cases_per_kloc + requester_succ_rate + followers +
  main_team_member + social_connection + prior_interaction_events +
  has_ci

# Split dataset into training and testing
samples <- sample(nrow(data), size = 0.25 * nrow(data))
test.data <- data[samples,]
train.data <- data[-samples,]

# Initial experiments with rf
rf <- randomForest(model, data = train.data, importance = T, do.trace = T)
print(rf)
plot(rf)
varImp(rf)
varImpPlot(rf)

# Make a function for the above and start tuning
plot.rf <- function(rf) {
  print(rf)
  plot(rf)
  varImp(rf)
  varImpPlot(rf)
}

# Perhaps more variables per tree?
rf <- randomForest(model, data = train.data, importance = T, do.trace = T,
                   mtry = 10, ntree = 100)
plot.rf(rf)

# Perhaps some dataset balancing?
nrow(subset(data, merged == T))
minority.class <- nrow(subset(train.data, merged == F))
rf <- randomForest(model, data = train.data, importance = T, do.trace = T, ntree = 200,
                   sampsize = c('FALSE' = minority.class,
                                'TRUE' = (2 * minority.class)))
plot.rf(rf)

# Let's throw in some other learners in the mix
# in parallel!
registerDoMC(3)

# Train a random forest model
rf.metrics <- random.forest(model, data)

# Train a binary logistic regression model
blr.metrics <- binary.logistic.regression(model, data)

# Train a naive bayes model
bayes.metrics <- naive.bayes(model, data)

all.metrics <- rbind(rf.metrics, blr.metrics, bayes.metrics)
all.metrics <- all.metrics[, -which(names(all.metrics) %in% c("tnr","tpr", "g.mean", "w.acc", "train.size", "test.size"))]
melted.metrics <- melt(all.metrics, id.vars = c('classifier', 'run'))
ggplot(melted.metrics)+
  aes(x = run, y = value, colour = classifier) +
  geom_point(aes(shape = classifier), size = 3) +
  scale_shape(solid = F) +
  geom_line() +
  facet_wrap(~variable, scales="free_y") +
  theme_bw() +
  theme(axis.title.y = element_blank()) +
  theme(axis.text.x = element_text(size = 8)) +
  theme(axis.text.y = element_text(size = 8)) +
  theme(legend.key = element_blank()) +
  theme(legend.position = "top")
